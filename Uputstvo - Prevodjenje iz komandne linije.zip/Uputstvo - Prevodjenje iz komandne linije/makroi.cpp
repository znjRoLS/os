#define naziv_makroa(param1, param2) param1param2 param1 param2 param1##param2 \
  param1##nastavak

naziv_makroa(argument1, argument2)

#define makro1 telo1
#define makro2 telo2

naziv_makroa(makro1, makro2)

#define novi_makro(p1,p2) naziv_makroa(p1, p2)

novi_makro(makro1,makro2)

#define makro3(param) param 1

neki tekst makro3(makro3(makro)) ostatak teksta

#define makro3(param) param##1

neki tekst makro3(makro) ostatak teksta