#ifndef _ZAGL2_H_
#define _ZAGL2_H_

#include "zagl1.h"

class B {
public:
  B();
};

#endif