#ifndef _ZAGL1_H_
#define _ZAGL1_H_

#include "zagl2.h"

class A{
public:
  A();
};

#endif