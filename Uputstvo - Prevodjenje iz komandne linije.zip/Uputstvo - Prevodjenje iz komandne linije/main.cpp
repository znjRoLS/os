#include <zagl1.h>
#include <zagl2.h>

A::A(){
//
}

B::B(){
//
}

int main(){
  return 0;
}