/*
 * vector.h
 *
 *  Created on: May 17, 2015
 *      Author: OS1
 */

#ifndef VECTOR_H_
#define VECTOR_H_

#include <list.h>

const long int defaultVectorSize = 5;

template <class T>
class Vector
{

	List<long int>* emptyList;

	long int size;

	T* arr;

public:

	Vector();
	~Vector();

	long int push(T);

	T remove(long int);

	T operator[](long int);

};


template <class T>
Vector<T>::Vector()
{
	size = defaultVectorSize;
	arr = new T[size];
	emptyList = new List<long int>();

	for (long int i = 0 ; i <size ; i ++)
	{
		//emptyList->print();
		emptyList->push(i);
		arr[i] = 0;
	}

}

template <class T>
Vector<T>::~Vector()
{
	delete arr;
	delete emptyList;
}

template <class T>
long int Vector<T>::push(T val)
{

	if (emptyList->isEmpty())
	{
		int newSize = size << 1;
		long int i;
		T* newArr = new T[newSize];

		for (i = 0 ; i < size ; i++)
			newArr[i] = arr[i];
		for ( ; i < newSize; i++)
		{
			emptyList->push(i);
			newArr[i] = 0;
		}
		size = newSize;
		delete arr;
		arr = newArr;
		if (DEBUG) cout << " resizing --------------------------------"<< size <<  endl;
	}

	int ind = emptyList->pop();
	arr[ind] = val;

	return ind;

}

template <class T>
T Vector<T>::remove(long int ind)
{
	emptyList->push(ind);
	T val = arr[ind];
	arr[ind] = 0;
	return val;
}

template <class T>
T Vector<T>::operator[](long int ind)
{

	return arr[ind];

}


#endif /* VECTOR_H_ */
