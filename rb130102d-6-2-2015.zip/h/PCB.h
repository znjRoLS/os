#ifndef PCB_H_
#define PCB_H_
#include <thread.h>
#include <list.h>

class PCB
{
public:

	//static ID autoid;
	StackSize stackSize;
	Time timeSlice, currentTime;
	Time sleeping;
	ID id;
	int state;
	List<int> *blocked;

	unsigned sp;
	unsigned bp;
	unsigned ss;
	unsigned *stack;

	PCB(StackSize, Time);
	~PCB();


	enum STATE{CREATED, READY,BLOCKED,RUNNING};


	int operator<(const PCB& b)
	{
		return sleeping < b.sleeping;
	}
};


#endif
