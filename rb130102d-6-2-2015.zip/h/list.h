/*
 * list.h
 *
 *  Created on: May 17, 2015
 *      Author: OS1
 */

#ifndef LIST_H_
#define LIST_H_

#include <iostream.h>

#define DEBUG 0

int sleepCompare(int a, int b);

template <class T>
class List
{

	typedef struct wrapper{
		T val;
		wrapper* next, *prev;

		wrapper(T v):val(v){};
	} wrapper;

	wrapper* head, *tail;

	int sorted;

	T (*compare)(T, T);

public:

	List(int sort , T (*cmp)(T,T));
	List();
	~List();

	void push(T val);

	//minmax is for sorted
	T pop(int minmax = 0);

	T top(int minmax = 0);

	int isEmpty();

	void print();

	T defaultCompare(T val1, T val2)
	{
		return val1 < val2;
	}
/*
	virtual int compare(T val1, T val2)
	{
		if (DEBUG) cout << "mlatka, virtual doesnt work "<<endl; //FIX THIS
		//return System::pcbs[val1]->sleeping < System::pcbs[val2]->sleeping;
		return sleepCompare(val1, val2);
		//return val1 < val2;

	}
*/
};

template <class T>
void List<T>::print()
{
	wrapper* curr = head;
	while(curr){
		cout << curr->val << " ";
		curr = curr->next;
	}

	cout << endl;
}

template <class T>
List<T>::List()
{
	sorted = 0;
	head= tail = 0;
}

template <class T>
List<T>::List(int sort, T(*cmp)(T,T))
{
	sorted = sort;
	head = tail = 0;
	compare = cmp;
}

template <class T>
List<T>::~List()
{
	wrapper * old;

	while(head)
	{
		old = head;
		head = head->next;
		delete old;
	}
}

template <class T>
void List<T>::push(T val)
{

	if (DEBUG) cout << "pushing " << val << endl;

	wrapper *w = new wrapper(val);
	wrapper *front = head;

	if (!head)
	{
		head = tail = w;
		w->next = w->prev = 0;
		return;
	}

	if (sorted)
	{
		//while (front && *(front->val) < *(val))
		while((front!=0) && compare(front->val, val))
		{
			front = front->next;
			//*(val) -= *(front->val);		//storing differences
		}


		if (front)	//shouldn't be last
		{
			w->prev = front->prev;
			w->next = front;
			front->prev = w;
			if (w->prev)
				w->prev->next = w;
			else
			{
				head = w;
			}
			return;

		}


	}
/*
	//put in in front of "front" NOOOOOOO
	w->next = front;
	w->prev = front->prev;
	w->next->prev = w;
	if (w->prev)
		w->prev->next = w;
	else		//this is the new head
		head = w;
	*/

	//put it on tail
	w->prev = tail;
	w->next = 0;
	tail = tail->next = w;


}


template <class T>
T List<T>::pop(int minmax)
{

	if (!head)
		return 0;

	if (sorted && minmax)	//should return last element
	{
		T val = tail->val;
		if (!tail->prev)	//this is the only element
		{
			delete tail;
			tail = head = 0;
		}

		else
		{
			tail = tail->prev;
			delete tail->next;
			tail->next = 0;
		}

		return val;
	}

	else
	{
		T val = head->val;
		if (!head->next)	//this is the only element
		{
			delete head;
			tail = head = 0;
		}

		else
		{
			head = head->next;
			delete head->prev;
			head->prev = 0;
		}

		return val;
	}
}


template <class T>
T List<T>::top(int minmax)
{
	if (!head)
		return 0;
	if (sorted && minmax)
		return tail->val;
	return head->val;
}


template <class T>
int List<T>::isEmpty()
{
	return !head;
}



#endif /* LIST_H_ */
