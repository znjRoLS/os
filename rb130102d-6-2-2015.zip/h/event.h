/*
 * event.h
 *
 *  Created on: May 27, 2015
 *      Author: OS1
 */

#ifndef EVENT_H_
#define EVENT_H_

#include <thread.h>
#include <ivtentry.h>
#include <system.h>
#include <thread.h>

typedef unsigned char IVTNo;

class Event{

	friend class IVTEntry;
public:

	Event(IVTNo ivtNo);
	~Event ();

	void wait();

protected:
	void signal();

private:
	ID id;
	int createEvent();
	IVTNo ivtnumber;
};


#endif /* EVENT_H_ */
