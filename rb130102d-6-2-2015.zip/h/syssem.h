/*
 * syssem.h
 *
 *  Created on: May 26, 2015
 *      Author: OS1
 */

#ifndef SYSSEM_H_
#define SYSSEM_H_


#include <list.h>
#include <system.h>

class SysSemaphore
{
public:


	SysSemaphore(int);
	~SysSemaphore();
	//1 if we should change blocked
	void signal();
	void wait();
	int getVal(){return val;}

private:
	int val;
	List<int> *blocked;

};




#endif /* SYSSEM_H_ */
