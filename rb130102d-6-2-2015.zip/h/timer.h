/*
 * timer.h
 *
 *  Created on: May 17, 2015
 *      Author: OS1
 */

#ifndef TIMER_H_
#define TIMER_H_

class Timer
{

public:

	static void interrupt(*oldTimer)(...);
	static void interrupt(*newTimer)(...);

	static unsigned int elapsed;		//FIX THISSSSS

	static void initializeTimer(void interrupt(*)(...));
	static void restoreTimer();
};



#endif /* TIMER_H_ */
