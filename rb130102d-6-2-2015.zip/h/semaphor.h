/*
 * semaphor.h
 *
 *  Created on: May 26, 2015
 *      Author: OS1
 */

#ifndef SEMAPHOR_H_
#define SEMAPHOR_H_

#include <thread.h>


class Semaphore{
public:
	Semaphore (int init = 1);
	virtual ~Semaphore();

	virtual void wait();
	virtual void signal();

	int val () const ;	//Returns the current value of the semaphore

private:
	ID id;
	ID create(int);
};


#endif /* SEMAPHOR_H_ */
