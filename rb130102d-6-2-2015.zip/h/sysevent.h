/*
 * sysevent.h
 *
 *  Created on: May 27, 2015
 *      Author: OS1
 */

#ifndef SYSEVENT_H_
#define SYSEVENT_H_

#include <list.h>

class SysEvent
{
public:

	SysEvent();
	~SysEvent();

	void signal();
	void wait();
private:
	List<int> *blocked;
};



#endif /* SYSEVENT_H_ */
