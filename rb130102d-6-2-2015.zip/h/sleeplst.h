/*
 * sleeplst.h
 *
 *  Created on: May 27, 2015
 *      Author: OS1
 */

#ifndef SLEEPLST_H_
#define SLEEPLST_H_

#include <list.h>

template <class T>
class ListSleeping : public List<T>
{

public:
	ListSleeping(int v, ):List<T>(v){};

	int compare(T,T){cout << "whaaa" << endl;};

};


template < class T >
int ListSleeping<T>::compare(T val1, T val2)
{
	cout << "comparing" << endl;

	return System::pcbs[val1]->sleeping < System::pcbs[val2]->sleeping;
}



#endif /* SLEEPLST_H_ */
