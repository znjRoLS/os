/*
 * ivtentry.h
 *
 *  Created on: May 27, 2015
 *      Author: OS1
 */

#ifndef IVTENTRY_H_
#define IVTENTRY_H_
#define NUM_ENTRY 255

#define PREPAREENTRY(num, callOld)\
	void interrupt interruptRoutine##num(...);\
	IVTEntry i(num, interruptRoutine##num);\
	void interrupt interruptRoutine##num(...)\
{	i.signal();\
	if (DEBUG) cout << "im in interrupt ##num " << endl;\
	if (callOld) i.oldRoutine();}

typedef unsigned char IVTNo;

#include <event.h>

class Event;

class IVTEntry
{
public:

	IVTEntry(IVTNo, void interrupt (*)(...));
	~IVTEntry();

	static IVTEntry* getIVTE(int);
	void interrupt (*oldRoutine)(...);

	void signal();

	void setEvent(Event*);

private:

	IVTNo entryNum;
	Event* event;

	static IVTEntry* IVT[NUM_ENTRY];
};



#endif /* IVTENTRY_H_ */
