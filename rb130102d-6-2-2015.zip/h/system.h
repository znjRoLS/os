/*
 * system.h
 *
 *  Created on: May 16, 2015
 *      Author: OS1
 */

#ifndef SYSTEM_H_
#define SYSTEM_H_

#define DEBUG 0

#include <PCB.h>
#include <schedule.h>
#include <vector.h>
#include <sleeplst.h>
#include <timer.h>
#include <syssem.h>
#include <sysevent.h>

//void interrupt controller(unsigned,unsigned,unsigned,unsigned,unsigned,unsigned,unsigned,unsigned,unsigned);


class System
{

	friend class SysSemaphore;
	friend class SysEvent;
	//used for controller
	static unsigned PA, PB, PC, PD;


	static List<int> *sleeping;
	static Vector<SysSemaphore*> &semaphores;
	static Vector<SysEvent*> &events;

	static PCB* idle;

	static void createKernelThread();
	static void createSelfThread();
	static void createVectorPCB();
	static void initializeController();
	static void killKernelThread();
	static void killAllObjects();
	static void createIdleThread();
	static void idleLoop();
	static void unpack(unsigned*, int, ...);


	static void interruptHandler();
	static int releaseThread(List<int>*);
	//static void releaseThread(List<PCB*>*);
	static void blockThread(List<int>*);
	//static void blockThread(List<PCB*>*);
	static void getRunning();
	static void putRunning();


	static const void (*calls[20])(unsigned* stack);
	static void createThread(unsigned* stack);
	static void switchRunning(unsigned* stack);
	static void killThread(unsigned* stack);
	static void startThread(unsigned* stack);
	static void sleep(unsigned* stack);
	static void popSleep();
	static void waitToComplete(unsigned* stack);

	static void semaphoreCreate(unsigned* stack);
	static void semaphoreWait(unsigned* stack);
	static void semaphoreSignal(unsigned* stack);
	static void semaphoreVal(unsigned* stack);
	static void semaphoreDelete(unsigned* stack);

	static void eventCreate(unsigned*stack);
	static void eventWait(unsigned * stack);


public:
	static void eventSignal(int);

	static Vector<PCB*> &pcbs; // FIX THIS
	static PCB* running;
	static PCB* kernel;//and this
	static void interrupt controller(unsigned,unsigned,unsigned,unsigned,unsigned,unsigned,unsigned,unsigned,unsigned);
	static void interrupt backController();

	static void interrupt timer();

	static void start();
	static void stop();

	enum CALL {	CREATETHREAD, DISPATCH, STOPTHREAD , STARTTHREAD,\
				SLEEP, WAITTOCOMPLETE,\
				SEMAPHORECREATE, SEMAPHOREWAIT, SEMAPHORESIGNAL, SEMAPHOREVAL, SEMAPHOREDELETE,\
				EVENTCREATE, EVENTWAIT};
};


#endif /* SYSTEM_H_ */
