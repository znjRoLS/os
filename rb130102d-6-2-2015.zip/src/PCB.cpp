/*
 * PCB.cpp
 *
 *  Created on: May 15, 2015
 *      Author: OS1
 */
#include <PCB.h>

#include <iostream.h>
PCB::PCB(StackSize stackSize, Time timeSlice)
{
	this->stackSize = stackSize;
	this->timeSlice = this->currentTime = timeSlice;
	stack = new unsigned[stackSize];
	if (stack == 0)
		cout << "ERROR *** not enough memory" << endl;

	blocked = new List<int>();
}

PCB::~PCB()
{
	delete[] stack;
	delete blocked;
}
