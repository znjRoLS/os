/*
 * main.cpp
 *
 *  Created on: May 15, 2015
 *      Author: OS1
 */

#include <system.h>
#include <iostream.h>

int userMain(int,char**);

int main(int argc, char ** argv)
{


	System::start();

/*
	for ( long int i = 0; i < 50000; i++)
		if (!(i% 10000))
		{
			cout << "in main loop " << i << endl;
		}
*/

	int res =  userMain(argc,argv);

	System::stop();

	return res;
}


