/*
 * sysevent.cpp
 *
 *  Created on: May 27, 2015
 *      Author: OS1
 */
#include <sysevent.h>
#include <system.h>

SysEvent::SysEvent()
{
	blocked = new List<int>();
}

SysEvent::~SysEvent()
{
	if (!blocked->isEmpty())
	{
		int r = System::releaseThread(blocked);
		if (DEBUG) cout << " released " << r;
	}
	delete blocked;
}

void SysEvent::wait()
{
	System::blockThread(blocked);
}

void SysEvent::signal()
{
	int r = System::releaseThread(blocked);
	if (DEBUG) cout << " released " << r;
}
