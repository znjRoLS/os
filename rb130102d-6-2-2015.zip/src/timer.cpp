/*
 * timer.cpp
 *
 *  Created on: May 17, 2015
 *      Author: OS1
 */
#include <timer.h>
#include <dos.h>

void interrupt(*Timer::newTimer)(...);

void Timer::restoreTimer()
{
	//lock
	setvect(8,oldTimer);
	//unlock
}


void Timer::initializeTimer(void interrupt(*n)(...))
{
	newTimer = n;

	//lock
	oldTimer = getvect(8);
	setvect(8, (void interrupt(*)(...)) n);
	//unlock
}
