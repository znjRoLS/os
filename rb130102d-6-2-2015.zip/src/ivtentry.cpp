/*
 * ivtentry.cpp
 *
 *  Created on: May 27, 2015
 *      Author: OS1
 */
#include <ivtentry.h>
#include <dos.h>

IVTEntry* IVTEntry::IVT[NUM_ENTRY];

IVTEntry::IVTEntry(IVTNo ivtNo, void interrupt(*i)(...))
{
	entryNum = ivtNo;
	oldRoutine = getvect(ivtNo);
	setvect(ivtNo, i);
	IVT[ivtNo] = this;
}

IVTEntry::~IVTEntry()
{

	//cout << "restoring old keyboard" << endl;
	oldRoutine();
	setvect(entryNum, oldRoutine);
}

IVTEntry* IVTEntry::getIVTE(int entryNum)
{
	return IVT[entryNum];
}

void IVTEntry::signal()
{
	event->signal();
}

void IVTEntry::setEvent(Event* e)
{
	event = e;
}
