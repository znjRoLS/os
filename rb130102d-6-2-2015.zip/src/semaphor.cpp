/*
 * semaphor.cpp
 *
 *  Created on: May 26, 2015
 *      Author: OS1
 */
#include <semaphor.h>
#include <dos.h>
#include <system.h>
#include <thread.h>

Semaphore::Semaphore(int init)
{
	id = create(init);
}

Semaphore::~Semaphore()
{

	systemCall(System::SEMAPHOREDELETE, 1, id);

}

ID Semaphore::create(int val)
{
	ID id;

	systemCall(System::SEMAPHORECREATE, 3, val, FP_OFF(&id), FP_SEG(&id));

	return id;
}

void Semaphore::signal()
{
	systemCall(System::SEMAPHORESIGNAL, 1 , id);


}

void Semaphore::wait()
{
	systemCall(System::SEMAPHOREWAIT, 1 , id);

}

int Semaphore::val() const
{
	int val;

	systemCall(System::SEMAPHOREVAL, 3, id, FP_OFF(&val), FP_SEG(&val));

	return val;
}
