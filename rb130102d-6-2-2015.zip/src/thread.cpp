/*
 * thread.cpp
 *
 *  Created on: May 14, 2015
 *      Author: OS1
 */
#include <thread.h>
#include <system.h>
#include <iostream.h>
#include <dos.h>

Thread::Thread(StackSize stackSize, Time timeSlice)
{

	isComplete = 0;

	id = createThread(stackSize, timeSlice);

}

Thread::~Thread()
{
	if (DEBUG) cout << "destructor thread" << endl;
	waitToComplete();
}

void Thread::wrapper(Thread* running)
{
	running->run();

	running->stop();
}


ID Thread::createThread(StackSize stackSize, Time timeSlice)
{
	unsigned id;

	systemCall(	System::CREATETHREAD, 9, timeSlice, stackSize, FP_OFF(&Thread::wrapper), FP_SEG(&Thread::wrapper),
				FP_OFF(&id), FP_SEG(&id), FP_OFF(this), FP_SEG(this));
//9 because stackSize is unsigned long = 2* unsigned

	return id;

}

void Thread::start()
{

	systemCall(System::STARTTHREAD, 1, id );
}

void Thread::stop()
{

	isComplete = 1;

	systemCall(System::STOPTHREAD, 0);



}

void dispatch()
{
	systemCall(System::DISPATCH, 0);
}

void Thread::sleep(Time t)
{

	systemCall(System::SLEEP, 1 , t);
}

void Thread::waitToComplete()
{

	if (!isComplete)
	{
		systemCall(System::WAITTOCOMPLETE, 1, id);
	}
	else
	{
		if (DEBUG) cout << "Thread: already completed " << id << endl;
	}
}

void systemCall(int code, int cnt, ...)
{

	//cout << "system call " << code << endl;
	unsigned *st = 0;
	if (cnt)
	{
		va_list args;
		va_start(args, cnt);

		st = new unsigned[cnt];
		//if (st == 0)
		//	cout << "*******************ERORRR" <<endl;

		for (int i = 0 ; i < cnt ; i++)
		{
			st[i] = va_arg(args, unsigned);
		}


		va_end(args);

	}

	_AX = code;
	_BX = FP_SEG(st);
	_CX = FP_OFF(st);
	asm int 64h;

	delete[] st;

}
