/*
 * syssem.cpp
 *
 *  Created on: May 26, 2015
 *      Author: OS1
 */
#include <syssem.h>

SysSemaphore::SysSemaphore(int v)
{
	val = v;
	blocked = new List<int>();
}

SysSemaphore::~SysSemaphore()
{

	while (!blocked->isEmpty()){
		int r =  System::releaseThread(blocked);
		if (DEBUG) cout << " released " << r;
	}

	delete blocked;
}

void SysSemaphore::signal()
{
	if (val++ < 0){
		int r =  System::releaseThread(blocked);
		if (DEBUG) cout << " released " << r;
	}
	if (DEBUG) cout << " val " << val;
}


void SysSemaphore::wait()
{
	if (--val < 0){
		System::blockThread(blocked);
		if (DEBUG) cout << " blocked ";
	}
	if (DEBUG) cout << " val " << val;

}


