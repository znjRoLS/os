/*
 * event.cpp
 *
 *  Created on: May 27, 2015
 *      Author: OS1
 */
#include <event.h>
#include <dos.h>

Event::Event(IVTNo ivtNo)
{
	IVTEntry::getIVTE(ivtNo)->setEvent(this);

	IVTNo ivtnumber = ivtNo;

	id = createEvent();
}


Event::~Event()
{
	delete IVTEntry::getIVTE(ivtnumber);
}


ID Event::createEvent()
{
	ID id;
	systemCall(System::EVENTCREATE, 2 , FP_OFF(&id), FP_SEG(&id));

	return id;
}

void Event::signal()
{
	System::eventSignal(id);
}

void Event::wait()
{
	systemCall(System::EVENTWAIT, 1 , id);
}
