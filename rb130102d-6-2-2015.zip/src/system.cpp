/*
 * system.cpp
 *
 *  Created on: May 16, 2015
 *      Author: OS1
 */
#include <system.h>
#include <dos.h>
#include <iostream.h>

int lockFlag;

const void (*System::calls[20])(unsigned*) = {
		System::createThread, System::switchRunning, System::killThread,
		System::startThread, System::sleep, System::waitToComplete,
		System::semaphoreCreate, System::semaphoreWait, System::semaphoreSignal, System::semaphoreVal, System::semaphoreDelete,
		System::eventCreate, System::eventWait};

unsigned System::PA;
unsigned System::PB;
unsigned System::PC;
unsigned System::PD;

Time Timer::elapsed;
PCB* System::running;
PCB* System::kernel;
PCB* System::idle;
Vector<PCB*> &System::pcbs = *(new Vector<PCB*>());
List<int> *System::sleeping = new List<int>(1, sleepCompare);//1 means its sorted
Vector<SysSemaphore*> &System::semaphores = *(new Vector<SysSemaphore*>());
Vector<SysEvent*> &System::events = *(new Vector<SysEvent*>());

void interrupt(*Timer::oldTimer)(...);


int sleepCompare(int a, int b)
{
	return System::pcbs[a]->sleeping < System::pcbs[b]->sleeping;
}



void System::createKernelThread()
{
	StackSize stackSize = 4096*5;
	Time timeSlice=  0;
	void (*body)() = System::interruptHandler;
	PCB* newPCB = new PCB(stackSize, timeSlice);

	unsigned *currSt = newPCB->stack + stackSize;

	*(--currSt) = 0x200;//set I flag
	*(--currSt) = FP_SEG(body);
	*(--currSt) = FP_OFF(body);

	//because of interrupt poping all the registers;
	currSt -= 9;

	newPCB->sp = FP_OFF(currSt);
	newPCB->ss = FP_SEG(currSt);
	newPCB->bp = FP_OFF(currSt);

	kernel = newPCB;

	//call kernel first time to initialize
	asm int 64h;

	if (DEBUG) cout << "kernel init called success" << endl;
}

void System::createSelfThread()
{
	StackSize stackSize = 4096;
	Time timeSlice = 2;
	running = new PCB(stackSize, timeSlice);
	running->state = PCB::RUNNING;

	running->id = pcbs.push(running);

	if (DEBUG) cout << "usermain has id " << running->id << endl;
}



void System::initializeController()
{
	if (DEBUG) cout << "initialized controller" << endl;

	//lock

	setvect(100, (void interrupt(*)(...)) System::controller);
	setvect(101, (void interrupt(*)(...)) System::backController);

	//unlock
}


void System::createIdleThread()
{
	StackSize stackSize = 20;
	Time timeSlice = 1;
	idle = new PCB(stackSize, timeSlice);

	if (DEBUG) cout << " creating idle thread  " << endl;

	unsigned *currSt = idle->stack + stackSize;

	currSt -= 2; //cs,ip in wrapper function
	*(--currSt) = 0x200;//set I flag
	*(--currSt) = FP_SEG(idleLoop);
	*(--currSt) = FP_OFF(idleLoop);

	//because of interrupt poping all the registers;
		currSt -= 8;

	*(--currSt) = FP_OFF(currSt+12);

	idle->sp = FP_OFF(currSt);
	idle->ss = FP_SEG(currSt);
	idle->bp = FP_OFF(currSt);

	idle->id = -1;

}

void System::idleLoop()
{
	long i;
	if (DEBUG) cout << "first time in idle" << endl;
	while(1)
		if (++i%100000 == 0)
			if (DEBUG) cout << "im idlee !!!" << endl;
}

void System::killKernelThread()
{
	delete kernel;
}

void System::killAllObjects()
{
	//what should i do here.... cant remember
}

void System::start()
{
	lockFlag = 1;

	Timer::elapsed = 0;
	Timer::initializeTimer((void interrupt(*)(...))System::timer);
	initializeController();
	createSelfThread();
	createKernelThread();
	createIdleThread();

	lockFlag = 0;
}

void System::stop()
{
	lockFlag = 1;

	killAllObjects();

	killThread(0);
	killKernelThread();

	Timer::restoreTimer();

	if (DEBUG) cout << "system stopped !" << endl;
}



void tick();
void interrupt System::timer()
{
	if (DEBUG) cout << "-----------------TIMER !!! "<< endl;

	Timer::oldTimer();

	tick();

	Timer::elapsed++;


	while(!lockFlag && !sleeping->isEmpty() && pcbs[sleeping->top()]->sleeping < Timer::elapsed)
	{
		popSleep();
	}

	if (DEBUG) cout << "timer, elapsed " << Timer::elapsed << " and next poping at " << pcbs[sleeping->top()]->sleeping << " is " << sleeping->top() << endl;

	if (!lockFlag && --running->currentTime == 0)
	{
		PA = System::DISPATCH;

		running->currentTime = running->timeSlice;
		running->sp = _SP;
		running->ss = _SS;
		running->bp = _BP;

		_SP = kernel->sp;
		_SS = kernel->ss;
		_BP = kernel->bp;
	}

}

void interrupt System::controller(	unsigned pbp, unsigned pdi, unsigned psi,
							unsigned pds, unsigned pes, unsigned pdx,
							unsigned pcx, unsigned pbx, unsigned pax)
{

	//cout << "hey im the system controller, what shoud i do now ? Kernel running is " << running << endl;

	//transfer register values

	PA = pax;
	PB = pbx;
	PC = pcx;
	PD = pdx;

	//lock contex switching
	lockFlag = 1;

	//switch to kernelThread
	running->sp = _SP;
	running->ss = _SS;
	running->bp = _BP;

	_SP = kernel->sp;
	_SS = kernel->ss;
	_BP = kernel->bp;

}


void interrupt System::backController()
{
	//cout << "hey im the BACKcontroller, what shoud i do now ? Kernel running is " << running << endl;


	//switch back to user thread
	kernel->sp = _SP;
	kernel->ss = _SS;
	kernel->bp = _BP;

	_SP = running->sp;
	_BP = running->bp;
	_SS = running->ss;

	//unlock contex switching
	lockFlag = 0;

	if (DEBUG) cout << " and continuing with " << running->id << endl;
}

void System::interruptHandler()
{
	if (DEBUG) cout << "successfully initialized kernel !" << endl;

	while(1)
	{
		//backController();
		asm int 65h;

		//cout << "interrupt handler" << endl;
		calls[PA]((unsigned*)MK_FP(PB, PC));

	}

}


//gets new thread to run
void System::getRunning()
{
	if (!(running = Scheduler::get()))
	{
		running = idle;
		return;
	}

	running->state = PCB::RUNNING;
}

//puts running to scheduler and calls getRunning
void System::putRunning()
{
	if (running != idle)
	{
		running->state = PCB::READY;
		Scheduler::put(running);
	}
	getRunning();
}

//blockes current running thread and than calls getRunning
void System::blockThread(List<int> *blocked)
{
	running->state = PCB::BLOCKED;
	blocked->push(running->id);
	getRunning();
}

//releases thread from blocked list
int System::releaseThread(List<int> *blocked)
{
	ID idPCB = blocked->pop();
	pcbs[idPCB]->state = PCB::READY;
	Scheduler::put(pcbs[idPCB]);

	return idPCB;
}

//called directly
void System::eventSignal(int id)
{
	if (DEBUG) cout << "signaling event " << id;

	events[id]->signal();
}

void System::eventWait(unsigned *st)
{
	ID id;
	unpack(st, 1, &id);

	if (DEBUG) cout << "event wait " << id << " ";

	events[id]->wait();
}


void System::eventCreate(unsigned *st)
{
	if (DEBUG) cout << "event create ";

	unsigned id_OFF, id_SEG;
	unpack(st , 2 , &id_OFF, &id_SEG);

	ID* id  = (ID*)MK_FP(id_SEG, id_OFF);

	*id = events.push(new SysEvent());
	if (DEBUG) cout << *id;
}


void System::semaphoreDelete(unsigned *st)
{
	ID id;

	unpack(st, 1 ,&id);

	delete semaphores.remove(id);

}

void System::semaphoreVal(unsigned* st)
{
	if (DEBUG) cout << "sem val ";

	//unsigned *st = (unsigned*)MK_FP(PB,PC);

	ID id;
	unsigned valOFF, valSEG;

	unpack(st, 3, &id, &valOFF, &valSEG);

	int * val = (int*)MK_FP(valSEG,valOFF);

	*val = semaphores[id]->getVal();

	if (DEBUG) cout << *val << " id " << id;
}

void System::semaphoreSignal(unsigned* st)
{

	//unsigned *st = (unsigned*)MK_FP(PB,PC);

	ID id;

	unpack(st, 1 , &id);

	if (DEBUG) cout << "sem signal " << id << " ";

	semaphores[id]->signal();
}

void System::semaphoreWait(unsigned* st)
{

	ID id;
	unpack(st, 1, &id);

	if (DEBUG) cout << "sem wait " << id << " ";

	semaphores[id]->wait();

}


void System::semaphoreCreate(unsigned* st)
{

	unsigned val, idOFF, idSEG;
	unpack(st, 3, &val, &idOFF, &idSEG );

	unsigned * id = (unsigned*)MK_FP(idSEG,idOFF);

	SysSemaphore *newSem = new SysSemaphore(val);

	*id = semaphores.push(newSem);


	if (DEBUG) cout << "sem create " << *id << " val " << val;

}

void System::waitToComplete(unsigned* st)
{

	ID idWait;

	unpack(st, 1 , &idWait);

	ID id = running->id;

	if (DEBUG) cout << "thread " <<id << " blocked on thread " << idWait ;

	if (!pcbs[id] || !pcbs[idWait])
	{
		if (DEBUG) cout << "ERROR *** pcb not present " << id << endl;
		return;
	}
	if (pcbs[id]->state != PCB::RUNNING )
	{
		if (DEBUG) cout << "ERROR *** pcb not in running state "<< id << endl;
		return ;
	}
	if (pcbs[idWait]->state == PCB::CREATED)
	{
		if (DEBUG) cout << "ERROR *** pcb not started "<< id << endl;
		return ;
	}

	blockThread(pcbs[idWait]->blocked);
}


void System::popSleep()
{
	int r = releaseThread(sleeping);
	if (DEBUG) cout << "pop sleep " << r;
}


void System::sleep(unsigned* st)
{

	Time t;

	unpack(st, 1 ,&t);

	ID id = running->id;

	if (DEBUG) cout << "sleep " <<id << " for " << t + Timer::elapsed << ",";

	if (!pcbs[id])
	{
		if (DEBUG) cout << "ERROR *** pcb not present " << id << endl;
		return;
	}
	if (pcbs[id]->state != PCB::RUNNING)
	{
		if (DEBUG) cout << "ERROR *** pcb not in running state "<< id << endl;
		return ;
	}

	//pcbs[id]->state = PCB::BLOCKED;

	//blocked->push(new BlockedPCB(id,t + Timer::elapsed));

	running->sleeping = t + Timer::elapsed;

	blockThread(sleeping);

}

void System::startThread(unsigned* st)
{
	ID id;

	unpack(st, 1 , &id);

	if (DEBUG) cout << "starting thread " << id;

	if (!pcbs[id])
	{
		if (DEBUG) cout << "ERROR *** pcb not present " << id << endl;
		return;
	}
	if (pcbs[id]->state != PCB::CREATED)
	{
		if (DEBUG) cout << "ERROR *** pcb not in created state "<< id << endl;
		return ;
	}

	pcbs[id]->state = PCB::READY;

	Scheduler::put(pcbs[id]);

}


void System::killThread(unsigned* st)
{


	ID id = running->id;

	if (DEBUG) cout << "killing thread " << id;

	if (!pcbs[id])
	{
		if (DEBUG) cout << "ERROR *** pcb not present " << id << endl;
		return;
	}
	if (pcbs[id]->state != PCB::RUNNING)
	{
		if (DEBUG) cout << "ERROR *** pcb not in running state " << id << endl;
		return ;
	}

	while (!pcbs[id]->blocked->isEmpty())
	{

		/*
		int idAdd = pcbs[id]->blocked.pop();

		if (!pcbs[idAdd])
		{
			cout << "ERROR *** pcb not present " << idAdd << endl;
			return;
		}
		if (pcbs[idAdd]->state != PCB::BLOCKED)
		{
			cout << "ERROR *** pcb not in running state " << idAdd << endl;
			return ;
		}

		pcbs[idAdd]->state = PCB::READY;
		Scheduler::put(pcbs[idAdd]);
		*/

		int r = releaseThread(pcbs[id]->blocked);
		if (DEBUG) cout << " released " << r;
	}

	delete pcbs.remove(id);

	getRunning();

}


void System::switchRunning(unsigned* st)
{

	if (DEBUG) cout << "switch running " << running->id;

	putRunning();
}

void System::createThread(unsigned* st)
{
	if (DEBUG) cout << "creating thread in system" << endl;

	//unsigned *st = (unsigned*)MK_FP(PB, PC);

	/*
	Time timeSlice = *(st++);
	unsigned stackSizeLow = *(st++);
	unsigned stackSizeHigh = *(st++);
	StackSize stackSize = (((unsigned long)stackSizeHigh) << 16) + (unsigned long)stackSizeLow;
	unsigned bodyOFF = *(st++);
	unsigned bodySEG = *(st++);
	void (*body)() = (void (*)())MK_FP(bodySEG,bodyOFF);
	bodyOFF = *(st++);
	bodySEG = *(st++);
	unsigned * id = (unsigned*)MK_FP(bodySEG,bodyOFF);
	bodyOFF = *(st++);
	bodySEG = *(st++);
	//thread pointer

*/

	Time timeSlice;
	unsigned stackSizeLow, stackSizeHigh, bodyOFF, bodySEG, idOFF, idSEG, threadOFF, threadSEG;

	unpack (st, 9, &timeSlice, &stackSizeLow, &stackSizeHigh, &bodyOFF, &bodySEG, &idOFF, &idSEG, &threadOFF, &threadSEG);

	StackSize stackSize = (((unsigned long)stackSizeHigh) << 16) + (unsigned long)stackSizeLow;
	unsigned * id = (unsigned*)MK_FP(idSEG,idOFF);

	PCB* newPCB = new PCB(stackSize, timeSlice);

	//lets fill up the stack from behind
	unsigned *currSt = newPCB->stack + stackSize;

	*(--currSt) = threadSEG;
	*(--currSt) = threadOFF;
	currSt -= 2; 			//cs,ip in wrapper function
	*(--currSt) = 0x200;	//set I flag
	*(--currSt) = bodySEG;
	*(--currSt) = bodyOFF;
	currSt -= 8;			//because of interrupt poping all the registers;
	*(--currSt) = FP_OFF(currSt+12);

	newPCB->sp = FP_OFF(currSt);
	newPCB->ss = FP_SEG(currSt);
	newPCB->bp = FP_OFF(currSt);

	newPCB->state = PCB::CREATED;
	newPCB->id = *id = pcbs.push(newPCB);

	if (DEBUG) cout << "created thread with id " << *id;

}


void System::unpack(unsigned *st, int cnt, ... )
{

	va_list args;
	va_start(args, cnt);

	for (int i = 0 ; i < cnt ; i++)
	{
		*va_arg(args, unsigned*) = st[i];
	}


	va_end(args);

	//delete[] st;
}

void print(PCB* running)
{
	PCB* g = running;

	unsigned * currSt = g->stack + g->stackSize;
	for (int i = 0; i < 20; i++)
		cout << *(--currSt) << endl;

	Thread * mth = (Thread*) MK_FP( *(g->stack + g->stackSize-1), *(g->stack + g->stackSize - 2) );

	cout << "stack is at " << g->stack << endl;
	cout << "oldBP at " << g->stack + g->stackSize - 16 << " " << *(g->stack + g->stackSize - 16) << endl;
	cout << "and it should be " << g->stack + g->stackSize - 4 << endl;

	cout << "after poping bp,ds,cs,di,si,dx,cx,bx,ax i get " << endl;
	cout << "ip " << *(g->stack + g->stackSize-7) << endl;
	cout << "cs " << *(g->stack + g->stackSize-6) << endl;
	cout << "flag " << *(g->stack + g->stackSize-5) << endl;
	cout << "and we should jump to " << &Thread::wrapper << endl;
}

